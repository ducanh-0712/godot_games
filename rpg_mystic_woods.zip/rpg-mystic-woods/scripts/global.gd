extends Node


var player_current_attack = false

var current_scene = "Game"
var transition_scene = false

var play_exit_cliffside_posx = -90
var play_exit_cliffside_posy = -145

var play_start_posx = 0
var play_start_posy = 0

var game_first_loadin = true

func finish_changescenes():
	if transition_scene == true:
		
		if current_scene == "Game":
			current_scene = "cliffside"
		else:
			current_scene = "Game"
		transition_scene = false
