extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if Global.game_first_loadin == true:
		$player.position.x = Global.play_start_posx
		$player.position.y = Global.play_start_posy
	else:
		$player.position.x = Global.play_exit_cliffside_posx
		$player.position.y = Global.play_exit_cliffside_posy


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	change_scene()




func _on_cliffside_transition_point_body_entered(body: Node2D) -> void:
	if body.has_method("player"):
		Global.transition_scene = true


func _on_cliffside_transition_point_body_exited(body: Node2D) -> void:
	if body.has_method("player"):
		Global.transition_scene = false
		
func change_scene():
	if Global.transition_scene == true:
			get_tree().change_scene_to_file("res://scenes/cliffside.tscn")
			Global.game_first_loadin = false
			Global.finish_changescenes()
